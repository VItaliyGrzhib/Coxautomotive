﻿using System;

namespace CoxAuto.Service
{
    class Program
    {
        static void Main(string[] args)
        {
         
        }
    }
}
