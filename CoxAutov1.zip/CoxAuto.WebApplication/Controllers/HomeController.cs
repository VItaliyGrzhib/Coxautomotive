﻿using CoxAuto.Loader.Model;
using CoxAuto.Service.Service;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IO;


namespace CoxAuto.WebApplication.Controllers
{
    public class HomeController : Controller
    {
        private const string _root = "csvFiles";
        private string _dir { get; }
        private ILoader<SalesDataModel> _ldr { get; }


        public HomeController(IWebHostEnvironment env, ILoader<SalesDataModel> ldr)
        {
            _dir = env.ContentRootPath;
            _ldr = ldr;
        }
        public IActionResult Index() => View();

        public IEnumerable<SalesDataModel> FileInModel(IFormFile file)
        {
            var path = Path.Combine(_dir, _root, file.FileName);
            return _ldr.GetData(path);
        }
    }
}
