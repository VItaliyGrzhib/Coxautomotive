﻿using System.Collections.Generic;


namespace CoxAuto.Service.Service
{
    public interface ILoader<T>
    {
        IEnumerable<T> GetData(string path);
    }
}
