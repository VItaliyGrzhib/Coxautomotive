- create folder 'csvFiles' in the root of CoxAuto.WebApplication
- copy csv files  to 'csvFiles'
- run CoxAuto.WebApplication
- go https:\\localhost:5001
- choise csv file from 'csvFiles' folder

 